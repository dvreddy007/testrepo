import {Component, OnInit, Inject, OnDestroy} from '@angular/core';
// import {FileUploadService} from './fileupload.service'

@Component({
    templateUrl: './dialogdemo.html',
    
})

export class DialogDemo implements OnInit, OnDestroy {
    
    display: boolean = false;
    /* constructor (private fileUploadService: FileUploadService) {

    } */
    showUploadBtn: boolean = false;
    showDialog() {
        this.display = true;
    };

    findselectedFilelength() {     
     let fi = document.getElementById('fileName'); 
     // GET THE FILE INPUT AS VARIABLE.        

      // console.log(this.value);
        // VALIDATE OR CHECK IF ANY FILE IS SELECTED.
        /* if (fi.length > 0)
        {
        	this.showUploadBtn = true;
        	console.log(this.showUploadBtn);
        }
        */
        console.log(this.showUploadBtn);
        
    };  

    hideDialog() {
        this.display = false;
    };    

    ngOnInit(){
    // this.findselectedFilelength();
    };

    uploadfiles() {
    	console.log("clicked upload files...");

    }

    
    
    ngOnDestroy(){

    };

}