import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

@Injectable()

export class FileUploadService {
	
	constructor(private http:HttpClient) {}
	
uploadFiles(url, data) {  
  // var reqHeader = new HttpHeaders({ 'Accept': 'text/plain','No-Auth':'True' });
  var reqHeader = new HttpHeaders({ 'Authorization': 'Bearer ' + localStorage.getItem('userToken'), 'Content-Type': 'application/json', 'Accept': 'text/html,text/plan, application/json,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,*/*' });
return this.http.post(url, data, { headers: reqHeader});
}
}